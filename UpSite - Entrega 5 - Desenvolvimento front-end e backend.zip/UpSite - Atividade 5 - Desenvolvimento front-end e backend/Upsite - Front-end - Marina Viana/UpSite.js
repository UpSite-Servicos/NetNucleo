<script src="JavaScript.js"></script>
<script src="Validação.js"></script>
<script src="Integração entre interface e PHP.js"></script>
<script src="acessibilidade.js"></script>