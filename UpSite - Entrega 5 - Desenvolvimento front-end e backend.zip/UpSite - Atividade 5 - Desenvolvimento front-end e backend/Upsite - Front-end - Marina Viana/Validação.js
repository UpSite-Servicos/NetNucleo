/**
 * validacao.js
 * -----------------------------------------
 * Responsável pelas validações dos
 * formulários de login e cadastro.
 *
 * NÃO contém:
 * - Código PHP
 * - Consultas SQL
 * - Comunicação com o servidor
 * - Manipulação do banco de dados
 */


/* =========================================
   VALIDAÇÃO DE E-MAIL
========================================= */

function validarEmail(email) {

    const regra =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    return regra.test(email.trim());
}


/* =========================================
   VALIDAÇÃO DO LOGIN
========================================= */

function validarLogin(email, senha) {

    // Verifica se o e-mail foi preenchido
    if (email.trim() === "") {

        return "O e-mail é obrigatório.";
    }


    // Verifica se o formato do e-mail está correto
    if (!validarEmail(email)) {

        return "Digite um e-mail válido.";
    }


    // Verifica se a senha foi preenchida
    if (senha.trim() === "") {

        return "A senha é obrigatória.";
    }


    // Se não houver erro
    return null;
}


/* =========================================
   VALIDAÇÃO DO CADASTRO
========================================= */

function validarCadastro(
    nome,
    email,
    senha,
    confirmarSenha
) {

    // Verifica o nome
    if (nome.trim() === "") {

        return "O nome é obrigatório.";
    }


    // Verifica o tamanho do nome
    if (nome.trim().length < 3) {

        return "O nome deve possuir pelo menos 3 caracteres.";
    }


    // Verifica se o e-mail foi preenchido
    if (email.trim() === "") {

        return "O e-mail é obrigatório.";
    }


    // Verifica o formato do e-mail
    if (!validarEmail(email)) {

        return "Digite um e-mail válido.";
    }


    // Verifica se a senha foi preenchida
    if (senha.trim() === "") {

        return "A senha é obrigatória.";
    }


    // Verifica o tamanho da senha
    if (senha.length < 8) {

        return "A senha deve possuir pelo menos 8 caracteres.";
    }


    // Verifica se as senhas são iguais
    if (senha !== confirmarSenha) {

        return "As senhas não coincidem.";
    }


    // Se todas as validações forem aprovadas
    return null;
}


/* =========================================
   VALIDAÇÃO DE CAMPOS OBRIGATÓRIOS
========================================= */

function validarCampoObrigatorio(valor, nomeCampo) {

    if (valor.trim() === "") {

        return `O campo ${nomeCampo} é obrigatório.`;
    }

    return null;
}