

document.addEventListener("DOMContentLoaded", function () {

    /* =====================================
       CONFIGURAÇÕES
    ===================================== */

    const body = document.body;

    const botaoAumentar =
        document.querySelector("#aumentarTexto");

    const botaoDiminuir =
        document.querySelector("#diminuirTexto");

    const botaoNormal =
        document.querySelector("#textoNormal");

    const botaoContraste =
        document.querySelector("#altoContraste");


    /* =====================================
       TAMANHO DO TEXTO
    ===================================== */

    let tamanhoTexto = 100;

    const tamanhoMinimo = 80;
    const tamanhoMaximo = 150;
    const passo = 10;


    function atualizarTamanhoTexto() {

        document.documentElement.style.fontSize =
            `${tamanhoTexto}%`;

        localStorage.setItem(
            "tamanhoTexto",
            tamanhoTexto
        );
    }


    // Recupera a configuração salva
    const tamanhoSalvo =
        localStorage.getItem("tamanhoTexto");

    if (tamanhoSalvo) {

        tamanhoTexto =
            parseInt(tamanhoSalvo);

        atualizarTamanhoTexto();
    }


    /* =====================================
       AUMENTAR TEXTO
    ===================================== */

    if (botaoAumentar) {

        botaoAumentar.addEventListener(
            "click",
            function () {

                if (tamanhoTexto < tamanhoMaximo) {

                    tamanhoTexto += passo;

                    atualizarTamanhoTexto();
                }
            }
        );
    }


    /* =====================================
       DIMINUIR TEXTO
    ===================================== */

    if (botaoDiminuir) {

        botaoDiminuir.addEventListener(
            "click",
            function () {

                if (tamanhoTexto > tamanhoMinimo) {

                    tamanhoTexto -= passo;

                    atualizarTamanhoTexto();
                }
            }
        );
    }


    /* =====================================
       RESTAURAR TAMANHO
    ===================================== */

    if (botaoNormal) {

        botaoNormal.addEventListener(
            "click",
            function () {

                tamanhoTexto = 100;

                atualizarTamanhoTexto();
            }
        );
    }


    /* =====================================
       ALTO CONTRASTE
    ===================================== */

    if (botaoContraste) {

        botaoContraste.addEventListener(
            "click",
            function () {

                const contrasteAtivo =
                    body.classList.toggle(
                        "alto-contraste"
                    );

                botaoContraste.setAttribute(
                    "aria-pressed",
                    contrasteAtivo
                );

                localStorage.setItem(
                    "altoContraste",
                    contrasteAtivo
                );
            }
        );


        // Recupera preferência salva
        const contrasteSalvo =
            localStorage.getItem(
                "altoContraste"
            );

        if (contrasteSalvo === "true") {

            body.classList.add(
                "alto-contraste"
            );

            botaoContraste.setAttribute(
                "aria-pressed",
                "true"
            );
        }
    }


    /* =====================================
       FOCO VISÍVEL
    ===================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Tab") {

                body.classList.add(
                    "navegacao-teclado"
                );
            }
        }
    );


    document.addEventListener(
        "mousedown",
        function () {

            body.classList.remove(
                "navegacao-teclado"
            );
        }
    );


    /* =====================================
       ATALHO PARA CONTEÚDO PRINCIPAL
    ===================================== */

    const linkConteudo =
        document.querySelector(
            "#irParaConteudo"
        );

    const conteudoPrincipal =
        document.querySelector(
            "#conteudo-principal"
        );


    if (linkConteudo && conteudoPrincipal) {

        linkConteudo.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                conteudoPrincipal.setAttribute(
                    "tabindex",
                    "-1"
                );

                conteudoPrincipal.focus();

                conteudoPrincipal.removeAttribute(
                    "tabindex"
                );
            }
        );
    }


    /* =====================================
       REDUÇÃO DE MOVIMENTO
    ===================================== */

    const prefereMenosMovimento =
        window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        );


    function verificarMovimento() {

        if (prefereMenosMovimento.matches) {

            body.classList.add(
                "menos-movimento"
            );

        } else {

            body.classList.remove(
                "menos-movimento"
            );
        }
    }


    verificarMovimento();


    prefereMenosMovimento.addEventListener(
        "change",
        verificarMovimento
    );

});