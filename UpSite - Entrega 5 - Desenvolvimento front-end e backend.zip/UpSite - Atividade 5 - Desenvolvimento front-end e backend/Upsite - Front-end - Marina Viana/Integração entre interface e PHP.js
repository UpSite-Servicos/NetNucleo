/**
 * api.js
 * -----------------------------------------
 * Responsável pela comunicação entre
 * a interface e o PHP.
 *
 * Utiliza a Fetch API para enviar e
 * receber dados do servidor.
 *
 * NÃO contém:
 * - Validações de formulário
 * - Código HTML
 * - Consultas SQL
 * - Acesso direto ao MySQL
 */


/* =========================================
   CONFIGURAÇÃO DA API
========================================= */

const API_URL = "../index.php";


/* =========================================
   LOGIN
========================================= */

async function enviarLogin(email, senha) {

    try {

        const resposta = await fetch(
            `${API_URL}?route=login`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    email: email,
                    senha: senha
                })
            }
        );


        // Verifica se o servidor respondeu corretamente
        if (!resposta.ok) {

            throw new Error(
                `Erro HTTP: ${resposta.status}`
            );
        }


        // Converte a resposta para JSON
        const dados = await resposta.json();


        return dados;


    } catch (erro) {

        console.error(
            "Erro ao realizar login:",
            erro
        );


        return {
            sucesso: false,
            mensagem:
                "Não foi possível conectar ao servidor."
        };
    }
}


/* =========================================
   CADASTRO
========================================= */

async function enviarCadastro(
    nome,
    email,
    senha
) {

    try {

        const resposta = await fetch(
            `${API_URL}?route=cadastro`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    nome: nome,
                    email: email,
                    senha: senha
                })
            }
        );


        // Verifica a resposta do servidor
        if (!resposta.ok) {

            throw new Error(
                `Erro HTTP: ${resposta.status}`
            );
        }


        // Converte a resposta para JSON
        const dados = await resposta.json();


        return dados;


    } catch (erro) {

        console.error(
            "Erro ao realizar cadastro:",
            erro
        );


        return {
            sucesso: false,
            mensagem:
                "Não foi possível conectar ao servidor."
        };
    }
}


/* =========================================
   VERIFICAR SESSÃO
========================================= */

async function verificarSessao() {

    try {

        const resposta = await fetch(
            `${API_URL}?route=verificar-sessao`,
            {
                method: "GET",

                headers: {
                    "Content-Type":
                        "application/json"
                }
            }
        );


        if (!resposta.ok) {

            throw new Error(
                `Erro HTTP: ${resposta.status}`
            );
        }


        const dados = await resposta.json();


        return dados;


    } catch (erro) {

        console.error(
            "Erro ao verificar sessão:",
            erro
        );


        return {
            autenticado: false,
            mensagem:
                "Não foi possível verificar a sessão."
        };
    }
}


/* =========================================
   LOGOUT
========================================= */

async function fazerLogout() {

    try {

        const resposta = await fetch(
            `${API_URL}?route=logout`,
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                }
            }
        );


        if (!resposta.ok) {

            throw new Error(
                `Erro HTTP: ${resposta.status}`
            );
        }


        const dados = await resposta.json();


        return dados;


    } catch (erro) {

        console.error(
            "Erro ao sair:",
            erro
        );


        return {
            sucesso: false,
            mensagem:
                "Não foi possível encerrar a sessão."
        };
    }
}