/**
 * script.js
 * -----------------------------------------
 * JavaScript responsável pelas interações
 * da interface do sistema.
 *
 * NÃO contém:
 * - Validações de formulário
 * - Consultas ao banco de dados
 * - Código PHP
 * - Integração com o servidor
 */

document.addEventListener("DOMContentLoaded", function () {

    console.log("Sistema carregado com sucesso.");

    /* =====================================
       MOSTRAR / OCULTAR SENHA
    ===================================== */

    const botaoMostrarSenha =
        document.querySelector("#mostrarSenha");

    const campoSenha =
        document.querySelector("#senha");

    if (botaoMostrarSenha && campoSenha) {

        botaoMostrarSenha.addEventListener(
            "click",
            function () {

                if (campoSenha.type === "password") {

                    campoSenha.type = "text";

                    botaoMostrarSenha.textContent =
                        "Ocultar senha";

                    botaoMostrarSenha.setAttribute(
                        "aria-label",
                        "Ocultar senha"
                    );

                } else {

                    campoSenha.type = "password";

                    botaoMostrarSenha.textContent =
                        "Mostrar senha";

                    botaoMostrarSenha.setAttribute(
                        "aria-label",
                        "Mostrar senha"
                    );
                }
            }
        );
    }


    /* =====================================
       MENU MOBILE
    ===================================== */

    const botaoMenu =
        document.querySelector("#botaoMenu");

    const menu =
        document.querySelector("#menuPrincipal");

    if (botaoMenu && menu) {

        botaoMenu.addEventListener(
            "click",
            function () {

                const menuAberto =
                    menu.classList.toggle("menu-aberto");

                botaoMenu.setAttribute(
                    "aria-expanded",
                    menuAberto
                );
            }
        );
    }


    /* =====================================
       FECHAR MENU AO CLICAR EM UM LINK
    ===================================== */

    if (menu) {

        const linksMenu =
            menu.querySelectorAll("a");

        linksMenu.forEach(function (link) {

            link.addEventListener(
                "click",
                function () {

                    menu.classList.remove(
                        "menu-aberto"
                    );

                    if (botaoMenu) {

                        botaoMenu.setAttribute(
                            "aria-expanded",
                            "false"
                        );
                    }
                }
            );
        });
    }


    /* =====================================
       BOTÃO VOLTAR AO TOPO
    ===================================== */

    const botaoTopo =
        document.querySelector("#botaoTopo");

    if (botaoTopo) {

        botaoTopo.addEventListener(
            "click",
            function () {

                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                });
            }
        );
    }


    /* =====================================
       ESC PARA FECHAR O MENU
    ===================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {

                if (menu) {

                    menu.classList.remove(
                        "menu-aberto"
                    );
                }

                if (botaoMenu) {

                    botaoMenu.setAttribute(
                        "aria-expanded",
                        "false"
                    );
                }
            }
        }
    );

});