CREATE DATABASE sistema_academico;

USE sistema_academico;

CREATE TABLE cursos (
    id_curso INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE turmas (
    id_turma INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    id_curso INT NOT NULL,

    CONSTRAINT fk_turma_curso
        FOREIGN KEY (id_curso)
        REFERENCES cursos(id_curso)
);

CREATE TABLE materias (
    id_materia INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE instrutores (
    id_instrutor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE
);

CREATE TABLE salas (
    id_sala INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

CREATE TABLE periodos (
    id_periodo INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

CREATE TABLE aulas (
    id_aula INT AUTO_INCREMENT PRIMARY KEY,

    id_instrutor INT NOT NULL,
    id_materia INT NOT NULL,
    id_sala INT NOT NULL,
    id_turma INT NOT NULL,
    id_periodo INT NOT NULL,

    id_tipo INT,
    data DATE NOT NULL,
    duracao INT,

    FOREIGN KEY (id_instrutor)
        REFERENCES instrutores(id_instrutor),

    FOREIGN KEY (id_materia)
        REFERENCES materias(id_materia),

    FOREIGN KEY (id_sala)
        REFERENCES salas(id_sala),

    FOREIGN KEY (id_turma)
        REFERENCES turmas(id_turma),

    FOREIGN KEY (id_periodo)
        REFERENCES periodos(id_periodo)
);

CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo VARCHAR(30) DEFAULT 'usuario'
);