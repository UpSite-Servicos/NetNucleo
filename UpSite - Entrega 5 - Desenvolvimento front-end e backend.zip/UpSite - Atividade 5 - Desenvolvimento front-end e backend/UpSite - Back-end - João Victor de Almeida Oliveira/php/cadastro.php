<?php

require_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Acesso inválido.");
}

$nome = trim($_POST["nome"] ?? "");
$email = trim($_POST["email"] ?? "");
$senha = $_POST["senha"] ?? "";


if ($nome === "" || $email === "" || $senha === "") {
    die("Todos os campos são obrigatórios.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Digite um email válido.");
}

if (strlen($senha) < 6) {
    die("A senha deve possuir pelo menos 6 caracteres.");
}

$sql = "SELECT id_usuario FROM usuarios WHERE email = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows > 0) {
    die("Este email já está cadastrado.");
}

$senhaHash = password_hash($senha, PASSWORD_DEFAULT);

$sql = "INSERT INTO usuarios (nome, email, senha)
        VALUES (?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $nome, $email, $senhaHash);

if ($stmt->execute()) {
    echo "Cadastro realizado com sucesso!";
    echo "<br><a href='login.html'>Ir para o login</a>";
} else {
    echo "Erro ao realizar cadastro.";
}

$stmt->close();
$conn->close();

?>