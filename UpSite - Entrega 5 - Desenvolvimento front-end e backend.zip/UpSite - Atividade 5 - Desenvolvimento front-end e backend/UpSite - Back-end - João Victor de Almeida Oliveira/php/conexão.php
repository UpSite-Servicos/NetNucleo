<?php

$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "sistema_academico";

$conn = new mysqli(
    $servidor,
    $usuario,
    $senha,
    $banco
);

if ($conn->connect_error) {
    die("Erro ao conectar ao banco: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

echo "Conexão realizada com sucesso!";

?>