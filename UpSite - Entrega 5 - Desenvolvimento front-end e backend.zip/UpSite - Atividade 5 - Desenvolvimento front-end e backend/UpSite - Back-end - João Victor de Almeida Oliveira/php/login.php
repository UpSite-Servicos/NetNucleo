<?php

session_start();

require_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Acesso inválido.");
}

$email = trim($_POST["email"] ?? "");
$senha = $_POST["senha"] ?? "";


if ($email === "" || $senha === "") {
    die("Preencha o email e a senha.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Email inválido.");
}


$sql = "SELECT id_usuario, nome, email, senha, tipo
        FROM usuarios
        WHERE email = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    die("Email ou senha incorretos.");
}

$usuario = $resultado->fetch_assoc();


if (!password_verify($senha, $usuario["senha"])) {
    die("Email ou senha incorretos.");
}


session_regenerate_id(true);

$_SESSION["id_usuario"] = $usuario["id_usuario"];
$_SESSION["nome"] = $usuario["nome"];
$_SESSION["email"] = $usuario["email"];
$_SESSION["tipo"] = $usuario["tipo"];


header("Location: index.php");
exit;

?>