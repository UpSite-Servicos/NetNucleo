<?php $base = caminhoBase(); ?>
<?php if (estaLogado()): ?>
  </main>
</div>
<?php endif; ?>

<footer class="text-center text-muted small py-3">
  SISGED — Sistema de Gestão Educacional Dinâmico
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $base ?>/assets/js/script.js"></script>

<!-- Widget VLibras (governo brasileiro) -->
<div vw class="enabled">
  <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>
<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget('https://vlibras.gov.br/app');
</script>
</body>
</html>
